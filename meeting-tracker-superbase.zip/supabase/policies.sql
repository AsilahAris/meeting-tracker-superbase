-- Meeting Actions: row-level security policies for the public web page.
-- Run in the Supabase dashboard AFTER schema.sql: SQL Editor > New query > paste > Run.
-- Safe to run more than once.
--
-- SECURITY NOTE
-- The page uses the publishable (anon) key, which is visible to anyone who opens the site.
-- These policies therefore let ANYONE who can open the site read, add, change and delete
-- actions. That suits a small internal tool whose URL is not shared widely. To restrict it:
--   * turn on Vercel Deployment Protection (Settings > Deployment Protection), or
--   * add Supabase Auth and change "to anon" below to "to authenticated".

alter table public.meeting_actions enable row level security;

grant select, insert, update, delete on public.meeting_actions to anon;

drop policy if exists "anon can read actions"   on public.meeting_actions;
drop policy if exists "anon can add actions"    on public.meeting_actions;
drop policy if exists "anon can update actions" on public.meeting_actions;
drop policy if exists "anon can delete actions" on public.meeting_actions;

create policy "anon can read actions"   on public.meeting_actions
  for select to anon using (true);

create policy "anon can add actions"    on public.meeting_actions
  for insert to anon with check (true);

create policy "anon can update actions" on public.meeting_actions
  for update to anon using (true) with check (true);

create policy "anon can delete actions" on public.meeting_actions
  for delete to anon using (true);
