-- Meeting Actions: table definition.
-- Run in the Supabase dashboard: SQL Editor > New query > paste > Run.
-- Safe to run more than once.

create table if not exists public.meeting_actions (
  id         uuid primary key default gen_random_uuid(),
  text       text not null check (char_length(text) between 1 and 200),
  owner      text not null check (char_length(owner) between 1 and 60),
  due        date not null,
  done       boolean not null default false,
  is_sample  boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.meeting_actions enable row level security;

comment on table public.meeting_actions is
  'Actions agreed in team meetings. Read and written by the Meeting Actions web page.';

-- Optional: add a few sample actions so a fresh deployment is not empty.
-- The page shows a "Clear samples" button while any sample rows exist.
-- Remove these lines if you do not want samples.
insert into public.meeting_actions (text, owner, due, done, is_sample)
select * from (values
  ('Send the revised timeline to the client',        'Priya',    current_date - 3, false, true),
  ('Update the risk log with the supplier delay',    'Priya',    current_date + 2, false, true),
  ('Share the meeting notes with the wider team',    'Priya',    current_date - 1, true,  true),
  ('Confirm budget sign-off with finance',           'Daniel',   current_date,     false, true),
  ('Book the venue for the November offsite',        'Daniel',   current_date + 6, false, true),
  ('Draft the onboarding checklist for new starters','Mei Ling', current_date + 4, false, true),
  ('Review the vendor contract changes',             'Mei Ling', current_date - 2, false, true)
) as s(text, owner, due, done, is_sample)
where not exists (select 1 from public.meeting_actions);
