# Meeting Actions

A single-page meeting action tracker for teams that keep forgetting what was agreed.

- Add an action with an owner and a due date
- Actions are grouped by owner, with a tick box for done
- Open, done and overdue counts at the top, overdue actions in red
- Data is stored in Supabase, so everyone sees the same list (refreshes every 20 seconds)

It is one static file (`index.html`) with no build step.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | The whole app. Supabase URL and publishable key are set near the top of the script. |
| `supabase/schema.sql` | Creates the `meeting_actions` table (and optional sample rows). |
| `supabase/policies.sql` | Row-level security policies that let the page read and write the table. |
| `vercel.json` | Security headers, including a content security policy limited to your Supabase project. |

## Set up Supabase

1. In the Supabase dashboard open **SQL Editor**.
2. Run `supabase/schema.sql`.
3. Run `supabase/policies.sql`.

Both scripts are safe to run more than once. If the table already exists, step 2 changes nothing.

## Deploy to Vercel

1. In Vercel choose **Add New > Project** and import this GitHub repository.
2. Set **Framework Preset** to **Other**. Leave Build Command and Output Directory empty.
3. Click **Deploy**.

No environment variables are needed. If you change Supabase projects, update `SUPABASE_URL` and `SUPABASE_KEY` in `index.html`, and the `connect-src` host in `vercel.json`.

## Access and security

The publishable key is meant to be public, and it is visible to anyone who opens the site. What it can do is decided by `supabase/policies.sql`, which lets anyone who can open the site read, add, change and delete actions. That suits a small internal tool. To limit access, turn on **Deployment Protection** in Vercel, or add Supabase Auth and change `to anon` to `to authenticated` in the policies.

Never put a `service_role` or secret key in `index.html`.
